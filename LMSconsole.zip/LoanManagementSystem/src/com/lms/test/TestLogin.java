package com.lms.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.lms.dao.IUserDao;
import com.lms.dao.UserDaoImpl;
import com.lms.exception.LmsException;

public class TestLogin {
	

static IUserDao userDao =null;
	
	@BeforeClass
	public static void initialize() throws Exception {
		userDao =new UserDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidAdminLogin() {
		String[] credential = {"kush","kush123","admin"};
		
		try {
			
			assertTrue(userDao.authenticUser(credential));
		} catch (LmsException e) {
			System.err.println("Invalid admin details in junit "+e.getMessage());
		}
	}
	
	@Test
	public void testValidLadLogin() {
		String[] credential = {"abc","abc123","lad"};
		
		try {
			
			assertTrue(userDao.authenticUser(credential));
		} catch (LmsException e) {
			System.err.println("Invalid lad details in junit "+e.getMessage());
		}
	}

}
