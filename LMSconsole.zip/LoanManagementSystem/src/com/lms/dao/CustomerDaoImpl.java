package com.lms.dao;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class CustomerDaoImpl implements ICustomerDao
{
	static Logger logger=Logger.getRootLogger();
	
	private EntityManager entityManager = JPAUtil.getEntityManager();
	
	
	public CustomerDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : registerCustomer()
	 *  - Return type   : int
	 *  - Description   : To register the customer for loan
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {
		System.out.println(customer.getDob());
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(customer);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
		e.printStackTrace();
		logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		System.out.println(customer.getDob());
		logger.info("successful");
		return customer.getCustomerId();
		
	}
	
	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : applyLoan()
	 *  - Return type   : int
	 *  - Description   : To apply for loan
	 *  - Exception     : LmsException
*********************************************************************************/	

	@Override
	public int applyLoan(LoanApplication loan)	throws LmsException 
	{
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(loan);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
		e.printStackTrace();
		logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return loan.getApplicationId();
	}
	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : viewApplicationStatus()
	 *  - Description   : To apply for loan
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
		LoanApplication loan = entityManager.find(LoanApplication.class, applicationId);
		if(loan != null)
		{
			return loan;
		}
			return null;
		
		
	}

}
