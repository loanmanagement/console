package com.lms.dao;

import java.util.List;

import com.lms.entity.ApprovedLoans;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;

public interface ILadDao {
  
	
	boolean isRejected(int applicationId)
			throws LmsException;
	
	public boolean isInterviewDatedUpdated(int loanApplication,int noOfDays)
			throws LmsException;

	
	public boolean isApprovedOrRejectedAfterinterview(int loanApplication, String status) throws LmsException;

	public boolean isAdded(ApprovedLoans approvedLoans) throws LmsException;
	
	public LoanApplication findLoan(int id) throws LmsException;
	
	public List<LoanApplication> viewAllApplication() throws LmsException;
}
