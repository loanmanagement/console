package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.lms.entity.ApprovedLoans;
import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.CustomerServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.ICustomerService;
import com.lms.service.ILadService;
import com.lms.service.IUserService;
import com.lms.service.LadServiceImpl;
import com.lms.service.UserServiceImpl;

public class AfterLoginLad {

	IUserService userservice = new UserServiceImpl();
	IAdminService adminService = new AdminServiceImpl();
	Users users = new Users();
	ICustomerService customerService = new CustomerServiceImpl();
	CustomerDetails customer = new CustomerDetails();
	ILadService lad = new LadServiceImpl();
	LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();

	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	public void afterLoginLad() throws IOException, LmsException {

		String[] credentialLad = new String[2];
		System.out.println("Enter username");
		credentialLad[0] = br.readLine();
		System.out.println("enter Password");
		credentialLad[1] = br.readLine();
		boolean isAuthenticLad = userservice.authenticUser(credentialLad);
		if (isAuthenticLad) {
			do{
			System.out.println("Press 1 to view all");
			System.out.println("Press 2 to view specific loan program");
			System.out.println("Press 3 to reject before appointment");
			System.out.println("Press 4 to schedule appointment");
			System.out
					.println("Press 5 to approve Or Reject after Appointment");
			System.out.println("Press 6 to view all applications");
			System.out.println("Press 0 to exit ");
			int operationLad = Integer.parseInt(br.readLine());
			switch (operationLad) {
			case 0:
				System.out.println("Application exited successfully!!");
				System.exit(0);
				break;
			case 1:
				List<LoanProgramsOffered> viewAllLoans = null;
				viewAllLoans = adminService.viewAll();
				if (viewAllLoans == null) {
					System.out.println("No loan Program exist for this bank");
				} else {
					for (LoanProgramsOffered loansPrograms : viewAllLoans) {
						System.out.println(loansPrograms);
					}
				}
				break;
			case 2:
				System.out.println("Enter loan program Name");
				LoanProgramsOffered specificLoan = adminService.viewSprcific(br
						.readLine());
				System.out.println(specificLoan);
				break;
			case 3:
				System.out.println("Enter id to be Deleted");
				int toDeleteId = Integer.parseInt(br.readLine());
				boolean rejected = lad.isRejected(toDeleteId);
				if (rejected) {
					System.out.println("Application Deleted Successfully");
				} else {
					System.out
							.println("Cannot delete either Desn't exist or some other problem");
				}
				break;
			case 4:
				System.out.println("Enter Application id ");
				int appIdAppointment = Integer.parseInt(br.readLine());
				System.out
						.println("Enter no of days after which Appointment is to be set");
				int noOfDays = Integer.parseInt(br.readLine());
				boolean isAppointmentSet = (lad.isInterviewDatedUpdated(
						appIdAppointment, noOfDays));
				if (isAppointmentSet) {
					System.out.println("Appointment Date set successfully");
				} else {
					System.out.println("Cannot set appointment Id");
				}
				break;
			case 5:
				System.out.println("Enter Application Id");
				int appID = Integer.parseInt(br.readLine());
				System.out.println("Enter Status");
				String status = br.readLine();
				boolean isStatusUpdated = lad
						.isApprovedOrRejectedAfterinterview(appID, status);
				if (isStatusUpdated) {
					System.out.println("Status Updated Successfully");
					try {
						LoanApplication searchLoan = new LoanApplication();
						searchLoan = lad.findLoan(appID);
						ApprovedLoans approvedLoans = new ApprovedLoans();
						System.out.println("Enter name");
						approvedLoans.setCustomerNameString(br.readLine());
						System.out.println("Enter Amount of loan granted:");
						approvedLoans.setAmountOfLoanGranted(Integer.parseInt(br.readLine()));
						System.out.println("Enter down payment: ");
						approvedLoans.setDownPayement(Integer.parseInt(br.readLine()));
						System.out.println("Enter the monthly instalment");
						approvedLoans.setMonthlyInstallment(Integer.parseInt(br.readLine()));
						System.out.println("Enter the Time period");
						approvedLoans.setYearsTimePeriod(Integer.parseInt(br.readLine()));
						System.out.println("enter the rate of interest");
						approvedLoans.setRateOfInterest(Integer.parseInt(br.readLine()));
						System.out.println("enter the Total Amount Payable");
						approvedLoans.setTotalAmountPayable(Integer.parseInt(br.readLine()));
						approvedLoans.setApprovedLoan(searchLoan);
						lad.isAdded(approvedLoans);
					} catch (NumberFormatException e) {
						throw new LmsException(e.getMessage());
					}
				} else {
					System.out.println("cannot update");
				}
				break;
			case 6:
				List<LoanApplication> allApplication = null;
				allApplication = lad.viewAllApplication();
				if (allApplication == null) {
					System.out.println("No application as of yet");
				} else {
					for (LoanApplication applications : allApplication) {
						System.out.println(applications);
					}
				}
				
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			}while(true);
		} else {
			System.out.println("Invalid USERNAME or PASSWORD");
		}

	}
}
